const GM_GAME_ID = "jiss0lczfcqmu7hh3g6lm89vnj1foxdy"; // tavo GameMonetize Game ID

window.ads = {
  showInterstitial: function () {
    if (window.gmApi?.showInterstitial) gmApi.showInterstitial();
  },
  showRewarded: function (onReward) {
    if (window.gmApi?.showRewarded) {
      gmApi.showRewarded().then(() => {
        if (typeof onReward === "function") onReward();
      });
    } else {
      if (typeof onReward === "function") onReward();
    }
  }
};